#!/bin/sh

sbatch job_script.sh 0.0 1
sbatch job_script.sh 0.1 1
sbatch job_script.sh 0.3 1
sbatch job_script.sh 1.0 1
sbatch job_script.sh 3.0 1
sbatch job_script.sh 10.0 1

sbatch job_script.sh 0.0 3
sbatch job_script.sh 0.1 3
sbatch job_script.sh 0.3 3
sbatch job_script.sh 1.0 3
sbatch job_script.sh 3.0 3
sbatch job_script.sh 10.0 3


sbatch job_script.sh 0.0 5
sbatch job_script.sh 0.1 5
sbatch job_script.sh 0.3 5
sbatch job_script.sh 1.0 5
sbatch job_script.sh 3.0 5
sbatch job_script.sh 10.0 5

sbatch job_script.sh 0.0 7
sbatch job_script.sh 0.1 7
sbatch job_script.sh 0.3 7
sbatch job_script.sh 1.0 7
sbatch job_script.sh 3.0 7
sbatch job_script.sh 10.0 7

sbatch job_script.sh 0.0 9
sbatch job_script.sh 0.1 9
sbatch job_script.sh 0.3 9
sbatch job_script.sh 1.0 9
sbatch job_script.sh 3.0 9
sbatch job_script.sh 10.0 9

