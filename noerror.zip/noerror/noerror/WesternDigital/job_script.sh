#!/bin/sh
#SBATCH -t 6-23:59:59
#SBATCH -p defq
#SBATCH -o slurm_out_%A.out

module load anaconda/2019.10
python3 PCA_multiprocess_multiinput.py $1 $2
