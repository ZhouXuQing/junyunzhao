"""
=====================================
Loss curves with asymmetry
=====================================

Sometimes looking at the learned coefficients of a neural network can provide
insight into the learning behavior. For example if weights look unstructured,
maybe some were not used at all, or if very large coefficients exist, maybe
regularization was too low or the learning rate too high.

"""
import io
from scipy.io.arff import loadarff
import matplotlib as mpl
#mpl.use('Agg')
import matplotlib.pyplot as plt
from sklearn.datasets import get_data_home
from sklearn.externals.joblib import Memory
from sklearn.externals import joblib
import time
import pickle
from neural_network import PCAMLPClassifier
try:
    from urllib.request import urlopen
except ImportError:
    # Python 2
    from urllib2 import urlopen

from locale import atoi
import sys

print(__doc__)

memory = Memory(get_data_home())

@memory.cache()
def fetch_mnist():
    content = urlopen(
         'https://www.openml.org/data/download/52667/mnist_784.arff').read()
    data, meta = loadarff(io.StringIO(content.decode('utf8')))
    data = data.view([('pixels', '<f8', 784), ('class', '|S1')])
    return data['pixels'], data['class']

X, y = fetch_mnist()
X = X/255
# rescale the data, use the traditional train/test split
X_train, X_test = X[:60000], X[60000:]
y_train, y_test = y[:60000], y[60000:]

# mlp = MLPClassifier(hidden_layer_sizes=(100, 100), max_iter=400, alpha=1e-4,
#                     solver='sgd', verbose=10, tol=1e-4, random_state=1)

mlp = PCAMLPClassifier(hidden_layer_sizes=(100, ), max_iter=30, alpha=0.0000, activation="logistic",momentum=0,
                    solver='sgd', power_t=0.0, verbose=10,learning_rate="constant", nesterovs_momentum=False,tol=1e-6, random_state=1,
                    learning_rate_init=0.6, batch_size=1028, asymmetry=0, powerlaw=1,decomposition=True, early_stopping=False, pca=False,  krank= atoi(sys.argv[1]))





mlp._fit(X_train, y_train, incremental=False)
print("Training set score: %f" % mlp.score(X_train, y_train))
print("Test set score: %f" % mlp.score(X_test, y_test))
#joblib.dump(mlp,'C:/users/bdh1/neural_network/mplcleanstartn020_100_relumodif.pkl')
#mlp=joblib.load('C:/users/bdh1/neural_network/mplcleanstartn020_100_relumodif.pkl')

print(mlp.loss_curve_)

ax = plt.plot(mlp.loss_curve_)

plt.show()
