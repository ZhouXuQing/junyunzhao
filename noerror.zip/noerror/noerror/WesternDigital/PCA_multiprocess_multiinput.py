"""
=====================================
Loss curves with asymmetry
=====================================

"""
import io
from scipy.io.arff import loadarff
import matplotlib as mpl
#mpl.use('Agg')
import matplotlib.pyplot as plt
from sklearn.datasets import get_data_home
from sklearn.externals.joblib import Memory
from sklearn.externals import joblib
import multiprocessing
from multiprocessing import Process
import sys, getopt
import ast
import os
import time
import pickle
from neural_network import PCAMLPClassifier
try:
    from urllib.request import urlopen
except ImportError:
    # Python 2
    from urllib2 import urlopen
import pathlib
from scipy.optimize import minimize_scalar

import numpy as np 
np.seterr(divide='ignore', invalid='ignore')
from locale import atoi
import csv
print(__doc__)

memory = Memory(get_data_home())

@memory.cache()
def fetch_mnist():
    content = urlopen(
         'https://www.openml.org/data/download/52667/mnist_784.arff').read()
    data, meta = loadarff(io.StringIO(content.decode('utf8')))
    data = data.view([('pixels', '<f8', 784), ('class', '|S1')])
    return data['pixels'], data['class']

X, y = fetch_mnist()
X = X / 255
# rescale the data, use the traditional train/test split
X_train, X_test = X[:60000], X[60000:]
y_train, y_test = y[:60000], y[60000:]


defaultparameters= {'hidden_layer_sizes' : (100,),'max_iter':30,'activation' : "relu", 'learning_rate' : "adaptive", 'tol' : 1e-4, 'random_state' : 1,
                    'learning_rate_init' : 0.01, 'asymmetry' : float(sys.argv[1]),'batch_size' : 1024, 'decomposition' : True, 'pca' : False, 'krank' : atoi(sys.argv[2])}


if __name__ == '__main__':

    inputfile = ''
    outputfile = '../result/'
    dictionary = defaultparameters
    tempdictionary = defaultparameters
    mlp = PCAMLPClassifier(**defaultparameters)
    text_accuracy = []
    try:
        opts, args = getopt.getopt(sys.argv[1:], "hi:o:l:", ["help","ifile=", "ofile=", "dictionary="])
    except getopt.GetoptError:
        print
        'PCA_multiprocess_multiinput.py -i <inputfile> -o <outputfile> -l <dictionary>'
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print
            'PCA_multiprocess_multiinput.py -i <inputfile> -o <outputfile> -l <dictionary>'
            sys.exit()
        elif opt in ("-i", "--ifile"):
            inputfile = arg
            mlp = joblib.load(inputfile)
            dictionary['hidden_layer_sizes'] = mlp.hidden_layer_sizes
            dictionary['max_iter'] = mlp.max_iter
            dictionary['activation'] = mlp.activation
            dictionary['learning_rate'] = mlp.learning_rate
            dictionary['tol'] = mlp.tol
            dictionary['learning_rate_init'] = mlp.learning_rate_init
            dictionary['batch_size'] = mlp.batch_size
            dictionary['decomposition'] = mlp.decomposition
            dictionary['pca'] = mlp.pca
            dictionary['krank'] = mlp.krank
            dictionary['random_state'] = mlp.random_state
            dictionary['asymmetry'] = mlp.asymmetry
        elif opt in ("-o", "--ofile"):
            outputfile = arg
            print("wording directory: " + outputfile)
        elif opt in ("-l", "--dictionary"):
            tempdictionary = ast.literal_eval(arg)
            for key in tempdictionary:
                dictionary[key] = tempdictionary[key]
            mlp.hidden_layer_sizes = dictionary['hidden_layer_sizes']
            mlp.max_iter = dictionary['max_iter']
            mlp.activation = dictionary['activation']
            mlp.tol = dictionary['tol']
            mlp.learning_rate_init = dictionary['learning_rate_init']
            mlp.batch_size = dictionary['batch_size']
            mlp.decomposition = dictionary['decomposition']
            mlp.pca = dictionary['pca']
            mlp.random_state = dictionary['random_state']
            mlp.asymmetry = dictionary['asymmetry']
            mlp.krank = dictionary['krank']
            mlp.learning_rate = dictionary['learning_rate']
            mlp.warm_start = True
            try:
                mlp._optimizer.asymmetry = mlp.asymmetry
            except:
                print("code not instantiated")
        elif opt not in ("-o", "--ofile"):
            print("first run!")
            mlp = PCAMLPClassifier(**dictionary)


    def optimizelearningrate(x):
        train = PCAMLPClassifier(**defaultparameters)
        train.learning_rate_init = 10 ** x
        train.max_iter = 5
        train._fit(X_train, y_train)

        return min(train.loss_curve_)



    res = minimize_scalar(optimizelearningrate, method='bounded', bounds=(-3, 0),
                          options={'xatol': 1e-03, 'maxiter': 5, 'disp': 3})
    y = res.x
    print("10 ** y:",10 ** y)
    mlp.learning_rate_init = 10**y



    pth = outputfile.split('/')
    pth = pth[:-1]
    pth = '/'.join(pth)
    pathlib.Path(pth).mkdir(parents=True, exist_ok=True)
    f = open(outputfile + '.txt', "w+")
    print("working directory confirmed:" + pth)
    print(str(dictionary))

    f.write(str(dictionary))
    f.write("\n")


    for i in range(30):
        if i == 29:
            mlp.flag =1
        mlp._fit(X_train, y_train, incremental=False)
        f.write("Training set score: %f\n" % mlp.score(X_train, y_train))
        f.write("Test set score: %f\n" % mlp.score(X_test, y_test))
        text_accuracy.append(mlp.score(X_test, y_test))
        print("Training set score: %f\n" % mlp.score(X_train, y_train))
        print("Test set score: %f\n" % mlp.score(X_test, y_test))
        mlp.warm_start=True
        joblib.dump(mlp, outputfile + '_iter_'+ str(i)+'.pkl')
    f.write("WE HAZ FINISHED!!!1111!!!")
    f.close()
#Junyun
    test_acc=[str(i) for i in text_accuracy]
    filename = "ACC"+ "_Batch_" + str( mlp.batch_size) + "_asymmetry_" + str( mlp.asymmetry) +"_Rank." + str( mlp.krank )+ ".csv"
    with open(filename, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        m = len(test_acc)
        for i in range(m):
            writer.writerow([test_acc[i]])
