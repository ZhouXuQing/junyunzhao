#!/bin/sh

sbatch job_scriptlargegpu.sh 0.0 2
sbatch job_scriptlargegpu.sh 0.1 2
sbatch job_scriptlargegpu.sh 0.3 2
sbatch job_scriptlargegpu.sh 1.0 2
sbatch job_scriptlargegpu.sh 3.0 2
sbatch job_scriptlargegpu.sh 10.0 2

sbatch job_scriptlargegpu.sh 0.0 4
sbatch job_scriptlargegpu.sh 0.1 4
sbatch job_scriptlargegpu.sh 0.3 4
sbatch job_scriptlargegpu.sh 1.0 4
sbatch job_scriptlargegpu.sh 3.0 4
sbatch job_scriptlargegpu.sh 10.0 4


sbatch job_scriptlargegpu.sh 0.0 6
sbatch job_scriptlargegpu.sh 0.1 6
sbatch job_scriptlargegpu.sh 0.3 6
sbatch job_scriptlargegpu.sh 1.0 6
sbatch job_scriptlargegpu.sh 3.0 6
sbatch job_scriptlargegpu.sh 10.0 6

sbatch job_scriptlargegpu.sh 0.0 8
sbatch job_scriptlargegpu.sh 0.1 8
sbatch job_scriptlargegpu.sh 0.3 8
sbatch job_scriptlargegpu.sh 1.0 8
sbatch job_scriptlargegpu.sh 3.0 8
sbatch job_scriptlargegpu.sh 10.0 8

sbatch job_scriptlargegpu.sh 0.0 10
sbatch job_scriptlargegpu.sh 0.1 10
sbatch job_scriptlargegpu.sh 0.3 10
sbatch job_scriptlargegpu.sh 1.0 10
sbatch job_scriptlargegpu.sh 3.0 10
sbatch job_scriptlargegpu.sh 10.0 10

